DJANGO ADMIN:
user:       Kazbek
password:   Kazbek5kazbek55