from django.db import models
from django.utils import timezone

class FormSubmission(models.Model):
    STATUS_CHOICES = [
        ('pending', 'В ожидании'),
        ('approved', 'Одобрено'),
        ('rejected', 'Отклонено'),
    ]

    # Личные данные
    name = models.CharField(max_length=255, verbose_name="Имя")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    gender = models.CharField(max_length=10, verbose_name="Пол", choices=[('male', 'Мужчина'), ('female', 'Женщина')])
    country = models.CharField(max_length=100, verbose_name="Страна")
    region = models.CharField(max_length=100, verbose_name="Город/Регион")
    age = models.PositiveIntegerField(verbose_name="Возраст")
    nationality = models.CharField(max_length=100, verbose_name="Национальность")
    height = models.PositiveIntegerField(verbose_name="Рост (см)", null=True, blank=True)
    weight = models.PositiveIntegerField(verbose_name="Вес (кг)", null=True, blank=True)

    # Религиозные данные
    prayer = models.CharField(max_length=50, verbose_name="Читает намаз?") # Можно расширить choices
    beard = models.CharField(max_length=50, verbose_name="Носит бороду?") # Можно расширить choices
    quran = models.CharField(max_length=50, verbose_name="Читает Коран?") # Можно расширить choices
    madhhab = models.CharField(max_length=100, verbose_name="Мазхаб", blank=True)

    # Семейное положение и предпочтения
    maritalStatus = models.CharField(max_length=100, verbose_name="Семейное положение")
    children = models.CharField(max_length=100, verbose_name="Дети")
    relocation = models.CharField(max_length=50, verbose_name="Готовность к переезду") # Можно расширить choices
    desiredWifeAgeMin = models.PositiveIntegerField(verbose_name="Мин. возраст жены", null=True, blank=True)
    desiredWifeAgeMax = models.PositiveIntegerField(verbose_name="Макс. возраст жены", null=True, blank=True)

    # Образование и характер
    education = models.CharField(max_length=100, verbose_name="Образование", blank=True)
    character = models.TextField(verbose_name="Характер", blank=True) # В server.js это массив, здесь используем TextField

    # Контакты и доп. информация
    whatsapp = models.CharField(max_length=100, verbose_name="WhatsApp", blank=True)
    instagram = models.CharField(max_length=100, verbose_name="Instagram", blank=True)
    telegram = models.CharField(max_length=100, verbose_name="Telegram", blank=True)
    aboutMe = models.TextField(verbose_name="О себе", blank=True)
    aboutWife = models.TextField(verbose_name="О будущей жене", blank=True)
    photo = models.ImageField(upload_to='uploads/photos/', verbose_name="Фото", null=True, blank=True) # Путь относительно MEDIA_ROOT

    # Метаданные
    language = models.CharField(max_length=10, verbose_name="Язык анкеты", blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending', verbose_name="Статус")
    submittedAt = models.DateTimeField(default=timezone.now, verbose_name="Время отправки")

    def __str__(self):
        return f"Анкета от {self.name} ({self.phone})"

    class Meta:
        verbose_name = "Анкета"
        verbose_name_plural = "Анкеты"
        ordering = ['-submittedAt']

class UserProfile(models.Model):
    # Страница 1: Личные данные
    name = models.CharField(max_length=100, verbose_name="Имя")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    
    # Страница 2: Основные данные
    GENDER_CHOICES = [
        ('male', 'Мужчина'),
        ('female', 'Женщина'),
    ]
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, verbose_name="Пол")
    
    COUNTRY_CHOICES = [
        ('kazakhstan', 'Казахстан'),
        ('kyrgyzstan', 'Киргизия'),
        ('uzbekistan', 'Узбекистан'),
        ('russia', 'Россия'),
        ('indonesia', 'Индонезия'),
        ('other', 'Другое'),
    ]
    country = models.CharField(max_length=20, choices=COUNTRY_CHOICES, verbose_name="Страна")
    
    # Страница 3: Местоположение
    region = models.CharField(max_length=100, verbose_name="Город")
    
    # Страница 4: Возраст
    age = models.IntegerField(verbose_name="Возраст")
    
    # Страница 5: Религиозные данные (часть 1)
    nationality = models.CharField(max_length=100, verbose_name="Национальность")
    prayer = models.CharField(max_length=100, verbose_name="Чтение намаза")
    beard = models.CharField(max_length=100, blank=True, null=True, verbose_name="Наличие бороды")  # Необязательно для женщин
    
    # Страница 6: Религиозные данные (часть 2)
    quran = models.CharField(max_length=100, verbose_name="Чтение Корана")
    madhhab = models.CharField(max_length=100, blank=True, null=True, verbose_name="Мазхаб")
    marital_status = models.CharField(max_length=100, blank=True, null=True, verbose_name="Семейное положение")
    
    # Страница 7: Семейные данные
    children = models.CharField(max_length=100, blank=True, null=True, verbose_name="Дети")
    relocation = models.CharField(max_length=100, verbose_name="Готовность к переезду")
    
    # Страница 8: Предпочтения
    min_wife_age = models.IntegerField(verbose_name="Минимальный возраст жены", blank=True, null=True)  # Может быть необязательно для женщин
    max_wife_age = models.IntegerField(verbose_name="Максимальный возраст жены", blank=True, null=True)  # Может быть необязательно для женщин
    character = models.TextField(verbose_name="Характер", blank=True, null=True)
    
    # Страница 9: Физические данные
    height = models.IntegerField(verbose_name="Рост")
    weight = models.IntegerField(verbose_name="Вес")
    education = models.CharField(max_length=100, verbose_name="Образование")
    
    # Страница 10: Контактная информация
    whatsapp = models.CharField(max_length=100, blank=True, null=True, verbose_name="WhatsApp")
    instagram = models.CharField(max_length=100, blank=True, null=True, verbose_name="Instagram")
    telegram = models.CharField(max_length=100, blank=True, null=True, verbose_name="Telegram")
    
    # Страница 11: Дополнительная информация
    about_me = models.TextField(verbose_name="О себе")
    about_wife = models.TextField(verbose_name="О будущей жене", blank=True, null=True)  # Необязательно для женщин
    photo = models.ImageField(upload_to='profile_photos/', blank=True, null=True, verbose_name="Фотография")
    
    # Информация о тарифе
    TARIFF_CHOICES = [
        ('vip', 'ВИП ПАКЕТ'),
        ('site-vip', 'САЙТ ВИП'),
        ('standard', 'СТАНДАРТ'),
    ]
    tariff = models.CharField(max_length=20, choices=TARIFF_CHOICES, blank=True, null=True, verbose_name="Выбранный тариф")
    is_paid = models.BooleanField(default=False, verbose_name="Оплачено")
    
    # Метаданные
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Дата обновления")
    
    def __str__(self):
        return f"{self.name} ({self.phone})"
    
    class Meta:
        verbose_name = "Анкета пользователя"
        verbose_name_plural = "Анкеты пользователей"
