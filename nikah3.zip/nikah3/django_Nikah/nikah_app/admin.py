from django.contrib import admin
from .models import FormSubmission, UserProfile
from django.db.models import Q
from django.utils.translation import gettext_lazy as _

class AgeFilter(admin.SimpleListFilter):
    title = _('Возраст')
    parameter_name = 'age'

    def lookups(self, request, model_admin):
        return (
            ('18-25', _('18-25 лет')),
            ('26-35', _('26-35 лет')),
            ('36-45', _('36-45 лет')),
            ('46+', _('46+ лет')),
        )

    def queryset(self, request, queryset):
        if self.value() == '18-25':
            return queryset.filter(age__range=(18, 25))
        if self.value() == '26-35':
            return queryset.filter(age__range=(26, 35))
        if self.value() == '36-45':
            return queryset.filter(age__range=(36, 45))
        if self.value() == '46+':
            return queryset.filter(age__gte=46)

@admin.register(FormSubmission)
class FormSubmissionAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'gender', 'country', 'region', 'age', 'status', 'submittedAt')
    list_filter = ('status', 'gender', 'country', 'region', 'prayer', AgeFilter, 'submittedAt')
    search_fields = ('name', 'phone', 'region', 'aboutMe', 'nationality')
    readonly_fields = ('submittedAt',)
    fieldsets = (
        ('Личная информация', {
            'fields': ('name', 'phone', 'gender', 'country', 'region', 'age', 'nationality', 'height', 'weight')
        }),
        ('Религиозные данные', {
            'fields': ('prayer', 'beard', 'quran', 'madhhab')
        }),
        ('Семейное положение', {
            'fields': ('maritalStatus', 'children', 'relocation')
        }),
        ('Предпочтения', {
            'fields': ('desiredWifeAgeMin', 'desiredWifeAgeMax', 'character')
        }),
        ('Образование и контакты', {
            'fields': ('education', 'whatsapp', 'instagram', 'telegram')
        }),
        ('Дополнительная информация', {
            'fields': ('aboutMe', 'aboutWife', 'photo')
        }),
        ('Метаданные', {
            'fields': ('language', 'status', 'submittedAt'),
            'classes': ('collapse',),
        }),
    )
    
    # Действия в админке
    actions = ['approve_submissions', 'reject_submissions']
    
    def approve_submissions(self, request, queryset):
        queryset.update(status='approved')
    approve_submissions.short_description = "Одобрить выбранные анкеты"
    
    def reject_submissions(self, request, queryset):
        queryset.update(status='rejected')
    reject_submissions.short_description = "Отклонить выбранные анкеты"

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'gender', 'country', 'region', 'age', 'created_at', 'is_paid')
    search_fields = ('name', 'phone', 'region', 'about_me', 'nationality')
    list_filter = ('gender', 'country', 'region', AgeFilter, 'created_at', 'is_paid', 'tariff')
    ordering = ('-created_at',)
    fieldsets = (
        ('Личные данные', {
            'fields': ('name', 'phone', 'gender', 'country', 'region', 'age')
        }),
        ('Религиозные данные', {
            'fields': ('nationality', 'prayer', 'beard', 'quran', 'madhhab', 'marital_status')
        }),
        ('Семейные данные', {
            'fields': ('children', 'relocation')
        }),
        ('Предпочтения', {
            'fields': ('min_wife_age', 'max_wife_age', 'character')
        }),
        ('Физические данные', {
            'fields': ('height', 'weight', 'education')
        }),
        ('Контактная информация', {
            'fields': ('whatsapp', 'instagram', 'telegram')
        }),
        ('Дополнительная информация', {
            'fields': ('about_me', 'about_wife', 'photo')
        }),
    )
