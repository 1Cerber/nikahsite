from rest_framework import serializers
from .models import FormSubmission

class FormSubmissionSerializer(serializers.ModelSerializer):
    """Сериализатор для модели FormSubmission - отображает все поля"""
    class Meta:
        model = FormSubmission
        fields = '__all__'

class FormSubmissionListSerializer(serializers.ModelSerializer):
    """Сериализатор для списка FormSubmission - отображает только основные поля"""
    class Meta:
        model = FormSubmission
        fields = ['id', 'name', 'gender', 'age', 'country', 'region', 'submittedAt', 'status']

class FormSubmissionCreateSerializer(serializers.ModelSerializer):
    """Сериализатор для создания FormSubmission - включает валидацию данных"""
    class Meta:
        model = FormSubmission
        exclude = ['status', 'submittedAt']  # Исключаем поля, которые заполняются автоматически
        
    def validate_phone(self, value):
        """Проверка номера телефона - минимум 10 цифр"""
        digits = ''.join(filter(str.isdigit, value))
        if len(digits) < 10:
            raise serializers.ValidationError("Телефон должен содержать минимум 10 цифр")
        return value
    
    def validate_age(self, value):
        """Проверка возраста - должен быть между 18 и 65"""
        if value < 18 or value > 65:
            raise serializers.ValidationError("Возраст должен быть между 18 и 65 годами")
        return value
    
    def validate(self, data):
        """Дополнительная валидация нескольких полей"""
        if 'desiredWifeAgeMin' in data and 'desiredWifeAgeMax' in data:
            if data['desiredWifeAgeMin'] > data['desiredWifeAgeMax']:
                raise serializers.ValidationError({
                    "desiredWifeAgeMin": "Минимальный возраст жены не может быть больше максимального"
                })
        return data 