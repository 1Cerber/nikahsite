from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views
from . import api_views

app_name = 'nikah_app'

# Настраиваем маршруты API с помощью роутера DRF
router = DefaultRouter()
router.register(r'submissions', api_views.FormSubmissionViewSet)

urlpatterns = [
    # Основной маршрут к HTML-странице
    path('', views.index, name='index'),
    
    # Маршрут для отправки формы (без API)
    path('submit/', views.submit_form, name='submit_form'),
    
    # Маршруты API
    path('api/', include(router.urls)),
    
    # Маршрут для отправки анкеты
    path('api/submit-profile/', views.submit_profile, name='submit_profile'),
    
    # Дополнительный маршрут для отправки анкеты (для прямого доступа без префикса 'api')
    path('submit-profile/', views.submit_profile, name='submit_profile_direct'),
] 