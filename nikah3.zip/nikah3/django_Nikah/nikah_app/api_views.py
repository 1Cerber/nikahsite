from rest_framework import viewsets, filters, status
from rest_framework.response import Response
from rest_framework.decorators import action
from django.db.models import Q
from django.shortcuts import get_object_or_404
from .models import FormSubmission
from .serializers import (
    FormSubmissionSerializer, 
    FormSubmissionListSerializer, 
    FormSubmissionCreateSerializer
)

class FormSubmissionViewSet(viewsets.ModelViewSet):
    """ViewSet для всех операций с анкетами"""
    queryset = FormSubmission.objects.all()
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'phone', 'country', 'region']
    ordering_fields = ['submittedAt', 'age', 'name']
    ordering = ['-submittedAt']  # По умолчанию сортировка по времени отправки (от новых к старым)
    
    def get_serializer_class(self):
        """Выбор сериализатора в зависимости от действия"""
        if self.action == 'list':
            return FormSubmissionListSerializer
        elif self.action == 'create':
            return FormSubmissionCreateSerializer
        return FormSubmissionSerializer
    
    def get_queryset(self):
        """Фильтрация результатов на основе параметров запроса"""
        queryset = FormSubmission.objects.all()
        
        # Фильтрация по полу
        gender = self.request.query_params.get('gender')
        if gender:
            queryset = queryset.filter(gender=gender)
        
        # Фильтрация по стране
        country = self.request.query_params.get('country')
        if country:
            queryset = queryset.filter(country=country)
        
        # Фильтрация по статусу
        status_filter = self.request.query_params.get('status')
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        
        # Фильтрация по поисковому запросу (поиск по имени, телефону, стране)
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) | 
                Q(phone__icontains=search) | 
                Q(country__icontains=search) |
                Q(region__icontains=search)
            )
            
        return queryset
    
    @action(detail=True, methods=['patch'])
    def update_status(self, request, pk=None):
        """Специальный метод для обновления статуса анкеты"""
        submission = self.get_object()
        new_status = request.data.get('status')
        
        if not new_status or new_status not in dict(FormSubmission.STATUS_CHOICES).keys():
            return Response({'error': 'Неверный статус'}, status=status.HTTP_400_BAD_REQUEST)
            
        submission.status = new_status
        submission.save()
        
        serializer = self.get_serializer(submission)
        return Response(serializer.data)
    
    def perform_create(self, serializer):
        """Добавляем кастомную логику при создании анкеты"""
        # Например, обработка массива character если он передан как строка
        character = self.request.data.get('character')
        if character and isinstance(character, list):
            character = ','.join(character)  # Преобразуем список в строку с разделителями
            
        serializer.save(character=character)
        
    def destroy(self, request, *args, **kwargs):
        """Кастомная логика при удалении анкеты"""
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT) 