from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
import json
import os
from .models import FormSubmission, UserProfile

# Create your views here.

def index(request):
    """Отображение главной страницы с формой"""
    return render(request, 'nikah_app/index.html')

@csrf_exempt
def submit_form(request):
    """Обработчик отправки формы (для JavaScript-запросов без API)"""
    if request.method == 'POST':
        try:
            # Получаем данные формы
            data = {}
            for key, value in request.POST.items():
                data[key] = value
            
            # Обработка фото, если оно есть
            photo_file = None
            if 'photo' in request.FILES:
                photo = request.FILES['photo']
                file_path = os.path.join('uploads/photos/', photo.name)
                photo_file = default_storage.save(file_path, ContentFile(photo.read()))
                data['photo'] = photo_file
            
            # Преобразуем character из строки в список, если необходимо
            if 'character' in data and isinstance(data['character'], str):
                if ',' in data['character']:
                    data['character'] = data['character'].split(',')
                else:
                    data['character'] = [data['character']]
            
            # Создаем запись в базе данных
            form_submission = FormSubmission.objects.create(**data)
            
            # Возвращаем успешный ответ
            return JsonResponse({
                'success': True,
                'message': 'Форма успешно отправлена',
                'id': form_submission.id
            })
            
        except Exception as e:
            # В случае ошибки
            return JsonResponse({
                'success': False,
                'message': f'Ошибка при отправке формы: {str(e)}'
            }, status=400)
    
    # Если запрос не POST
    return JsonResponse({
        'success': False,
        'message': 'Метод не разрешен'
    }, status=405)

@csrf_exempt
def submit_profile(request):
    if request.method == 'POST':
        try:
            # Определяем тип запроса по Content-Type заголовку
            content_type = request.content_type or ''
            print(f"Content-Type: {content_type}")
            print(f"Данные: {request.POST.dict()}")
            
            # Для JSON-запроса (без файлов)
            if 'application/json' in content_type:
                # Если данные пришли в JSON-формате
                data = json.loads(request.body)
                print(f"JSON данные: {data}")
                
                # Создаем новый профиль пользователя
                profile = UserProfile(
                    # Страница 1
                    name=data.get('name', ''),
                    phone=data.get('phone', ''),
                    
                    # Страница 2
                    gender=data.get('gender', ''),
                    country=data.get('country', ''),
                    
                    # Страница 3
                    region=data.get('region', ''),
                    
                    # Страница 4
                    age=data.get('age', 0),
                    
                    # Страница 5
                    nationality=data.get('nationality', ''),
                    prayer=data.get('prayer', ''),
                    beard=data.get('beard', ''),
                    
                    # Страница 6
                    quran=data.get('quran', ''),
                    madhhab=data.get('madhhab', ''),
                    marital_status=data.get('marital_status', ''),
                    
                    # Страница 7
                    children=data.get('children', ''),
                    relocation=data.get('relocation', ''),
                    
                    # Страница 8
                    min_wife_age=data.get('min_wife_age', 0),
                    max_wife_age=data.get('max_wife_age', 0),
                    character=data.get('character', ''),
                    
                    # Страница 9
                    height=data.get('height', 0),
                    weight=data.get('weight', 0),
                    education=data.get('education', ''),
                    
                    # Страница 10
                    whatsapp=data.get('whatsapp', ''),
                    instagram=data.get('instagram', ''),
                    telegram=data.get('telegram', ''),
                    
                    # Страница 11
                    about_me=data.get('about_me', ''),
                    about_wife=data.get('about_wife', ''),
                    
                    # Информация о тарифе
                    tariff=data.get('tariff', ''),
                    is_paid=False  # По умолчанию не оплачено
                )
                
                profile.save()
                
                return JsonResponse({'success': True, 'message': 'Анкета успешно отправлена!'})
            
            # Для обычного POST запроса (multipart/form-data с файлами)
            else:
                # Выводим информацию для отладки
                print(f"POST данные: {request.POST}")
                print(f"FILES: {request.FILES}")
                
                # Проверяем обязательные поля
                for field in ['name', 'phone', 'gender', 'country']:
                    if not request.POST.get(field):
                        return JsonResponse({
                            'success': False, 
                            'message': f'Не заполнено обязательное поле: {field}'
                        })
                
                data = {
                    # Страница 1
                    'name': request.POST.get('name', ''),
                    'phone': request.POST.get('phone', ''),
                    
                    # Страница 2
                    'gender': request.POST.get('gender', ''),
                    'country': request.POST.get('country', ''),
                    
                    # Страница 3
                    'region': request.POST.get('region', ''),
                    
                    # Страница 4
                    'age': request.POST.get('age', 0) or 0,
                    
                    # Страница 5
                    'nationality': request.POST.get('nationality', ''),
                    'prayer': request.POST.get('prayer', ''),
                    'beard': request.POST.get('beard', ''),
                    
                    # Страница 6
                    'quran': request.POST.get('quran', ''),
                    'madhhab': request.POST.get('madhhab', ''),
                    'marital_status': request.POST.get('marital_status', ''),
                    
                    # Страница 7
                    'children': request.POST.get('children', ''),
                    'relocation': request.POST.get('relocation', ''),
                    
                    # Страница 8
                    'min_wife_age': request.POST.get('min_wife_age', 0) or 0,
                    'max_wife_age': request.POST.get('max_wife_age', 0) or 0,
                    'character': request.POST.get('character', ''),
                    
                    # Страница 9
                    'height': request.POST.get('height', 0) or 0,
                    'weight': request.POST.get('weight', 0) or 0,
                    'education': request.POST.get('education', ''),
                    
                    # Страница 10
                    'whatsapp': request.POST.get('whatsapp', ''),
                    'instagram': request.POST.get('instagram', ''),
                    'telegram': request.POST.get('telegram', ''),
                    
                    # Страница 11
                    'about_me': request.POST.get('about_me', ''),
                    'about_wife': request.POST.get('about_wife', ''),
                    
                    # Информация о тарифе
                    'tariff': request.POST.get('tariff', ''),
                    'is_paid': False  # По умолчанию не оплачено
                }
                
                # Преобразуем строковые значения в числовые, где это требуется
                for field in ['age', 'min_wife_age', 'max_wife_age', 'height', 'weight']:
                    try:
                        if data[field]:
                            data[field] = int(data[field])
                        else:
                            data[field] = 0
                    except (ValueError, TypeError):
                        data[field] = 0
                
                # Обработка фотографии
                photo = None
                if 'photo' in request.FILES:
                    photo = request.FILES.get('photo')
                
                try:
                    # Создаем новый профиль пользователя
                    profile = UserProfile(**data)
                    if photo:
                        profile.photo = photo
                    profile.save()
                    
                    return JsonResponse({'success': True, 'message': 'Анкета успешно отправлена!'})
                except Exception as inner_e:
                    print(f"Ошибка при сохранении профиля: {str(inner_e)}")
                    return JsonResponse({
                        'success': False, 
                        'message': f'Ошибка при сохранении анкеты: {str(inner_e)}'
                    })
                
        except Exception as e:
            print(f"Общая ошибка при отправке анкеты: {str(e)}")
            return JsonResponse({'success': False, 'message': f'Ошибка при отправке анкеты: {str(e)}'})
            
    return JsonResponse({'success': False, 'message': 'Метод не поддерживается'})
