// Nikah Space - Анкета: основной JS (рефакторинг)
// --------------------------------------------------
// 1. Переменные и константы
// --------------------------------------------------
document.addEventListener("DOMContentLoaded", function () {
  // DOM-элементы
    const formPages = document.querySelectorAll(".form-page");
    const prevBtn = document.querySelector(".prev-btn");
    const nextBtn = document.querySelector(".next-btn");
    const submitBtn = document.querySelector(".submit-btn");
    const progressBar = document.querySelector(".progress");
    const progressText = document.querySelector(".progress-text");
    const languageButtons = document.querySelectorAll(".lang-btn");
  const langSelector = document.querySelector(".lang-selector");
  const selectedLang = document.querySelector(".selected-lang");
  const langItems = document.querySelectorAll(".lang-item");
  const editBtn = document.querySelector(".edit-btn");
  const scrollToTopBtn = document.getElementById("scrollToTop");

  // Сначала создаем модальное окно с тарифами, чтобы оно было доступно до вызова submitForm
  // Добавляем HTML-код для модального окна с тарифами
  const tariffsModal = document.createElement('div');
  tariffsModal.classList.add('modal');
  tariffsModal.id = 'tariffs-modal';
  tariffsModal.innerHTML = `
    <div class="modal-content">
      <span class="close">&times;</span>
      <h2>Выберите тариф</h2>
      <p class="tariff-intro">Выберите подходящий вам тариф для размещения вашей анкеты на нашем сайте</p>
      <div class="tariffs-container">
        <div class="tariff-card">
          <div class="tariff-badge">Популярный</div>
          <h3>ТАРИФ ВИП ПАКЕТ</h3>
          <p class="tariff-price">15 000 ₸</p>
          <p class="tariff-duration">30 дней</p>
          <div class="tariff-features">
            <div class="feature-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Размещение анкеты на сайте на 30 дней</span>
            </div>
            <div class="feature-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Доступ ко всем контактам</span>
            </div>
            <div class="feature-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Приоритетное размещение анкеты</span>
            </div>
          </div>
          <button class="pay-btn" data-tariff="vip">Оплатить</button>
        </div>
        <div class="tariff-card premium">
          <div class="tariff-badge">Премиум</div>
          <h3>ТАРИФ САЙТ ВИП</h3>
          <p class="tariff-price">15 000 ₸</p>
          <p class="tariff-duration">30 дней</p>
          <div class="tariff-features">
            <div class="feature-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Доступ ко всем номерам на 30 дней</span>
            </div>
            <div class="feature-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Доступ ко всем фото на 30 дней</span>
            </div>
            <div class="feature-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Возможность отправлять анкету другим участникам</span>
            </div>
            <div class="feature-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Размещение анкеты на сайте на 30 дней</span>
            </div>
          </div>
          <button class="pay-btn" data-tariff="site-vip">Оплатить</button>
        </div>
        <div class="tariff-card">
          <div class="tariff-badge">Базовый</div>
          <h3>ТАРИФ СТАНДАРТ</h3>
          <p class="tariff-price">7 500 ₸</p>
          <p class="tariff-duration">30 дней</p>
          <div class="tariff-features">
            <div class="feature-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Размещение анкеты на сайте на 30 дней</span>
            </div>
            <div class="feature-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Базовый доступ к сервису</span>
            </div>
          </div>
          <button class="pay-btn" data-tariff="standard">Оплатить</button>
        </div>
      </div>
      <p class="tariff-note">После оплаты ваша анкета будет размещена на сайте в течение 24 часов</p>
    </div>
  `;
  document.body.appendChild(tariffsModal);

  // Добавляем стили для модального окна
  const modalStyles = document.createElement('style');
  modalStyles.textContent = `
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.6);
    }
    
    .modal-content {
      background-color: #fff;
      margin: 2% auto;
      padding: 30px;
      border-radius: 10px;
      max-width: 1000px;
      width: 90%;
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
      text-align: center;
    }
    
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      transition: color 0.3s;
      margin-right: 5px;
    }
    
    .close:hover {
      color: #000;
    }
    
    .modal-content h2 {
      color: #333;
      margin-top: 0;
      margin-bottom: 10px;
      font-size: 32px;
    }
    
    .tariff-intro {
      margin-bottom: 30px;
      color: #666;
      font-size: 18px;
      padding: 0 10px;
    }
    
    .tariffs-container {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
      margin-bottom: 20px;
    }
    
    .tariff-card {
      border: 1px solid #ddd;
      border-radius: 12px;
      padding: 25px;
      flex: 1;
      min-width: 250px;
      max-width: 300px;
      text-align: center;
      position: relative;
      transition: transform 0.3s, box-shadow 0.3s;
      background-color: #fff;
      margin: 10px;
    }
    
    .tariff-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    
    .tariff-card.premium {
      border-color: #28a745;
      box-shadow: 0 5px 15px rgba(40, 167, 69, 0.2);
    }
    
    .tariff-badge {
      position: absolute;
      top: -10px;
      left: 50%;
      transform: translateX(-50%);
      background-color: #28a745;
      color: white;
      padding: 5px 15px;
      border-radius: 20px;
      font-weight: bold;
      font-size: 14px;
    }
    
    .tariff-card h3 {
      color: #28a745;
      margin-top: 15px;
      margin-bottom: 10px;
      font-size: 22px;
    }
    
    .tariff-price {
      font-size: 28px;
      font-weight: bold;
      margin: 10px 0;
      color: #333;
    }
    
    .tariff-duration {
      font-size: 16px;
      color: #666;
      margin-bottom: 20px;
    }
    
    .tariff-features {
      text-align: left;
      margin: 20px 0;
    }
    
    .feature-item {
      display: flex;
      align-items: center;
      margin-bottom: 12px;
      font-size: 14px;
    }
    
    .feature-item svg {
      color: #28a745;
      margin-right: 10px;
      flex-shrink: 0;
      width: 16px;
      height: 16px;
    }
    
    .pay-btn {
      background-color: #28a745;
      color: white;
      border: none;
      padding: 12px 25px;
      margin-top: 15px;
      border-radius: 30px;
      cursor: pointer;
      font-size: 16px;
      font-weight: bold;
      transition: background-color 0.3s, transform 0.2s;
      width: 80%;
    }
    
    .pay-btn:hover {
      background-color: #218838;
      transform: scale(1.05);
    }
    
    .tariff-note {
      color: #666;
      font-size: 14px;
      margin-top: 20px;
      padding: 0 15px;
    }
    
    /* Медиа-запросы для адаптивности */
    
    /* Для планшетов */
    @media (max-width: 992px) {
      .modal-content {
        max-width: 90%;
        padding: 25px;
        margin: 5% auto;
      }
      
      .tariffs-container {
        flex-direction: row;
        flex-wrap: wrap;
        gap: 15px;
      }
      
      .tariff-card {
        flex: 0 0 calc(50% - 40px);
        min-width: auto;
        max-width: none;
      }
      
      .modal-content h2 {
        font-size: 28px;
      }
      
      .tariff-intro {
        font-size: 16px;
      }
    }
    
    /* Для мобильных устройств */
    @media (max-width: 768px) {
      .modal-content {
        padding: 20px 15px;
        width: 95%;
        margin: 5% auto;
      }
      
      .tariffs-container {
        flex-direction: column;
        align-items: center;
        gap: 20px;
      }
      
      .tariff-card {
        flex: none;
        width: 100%;
        max-width: 320px;
        margin: 0 0 15px 0;
        padding: 20px 15px;
      }
      
      .modal-content h2 {
        font-size: 24px;
      }
      
      .tariff-intro {
        font-size: 14px;
        margin-bottom: 20px;
      }
      
      .tariff-card h3 {
        font-size: 20px;
      }
      
      .tariff-price {
        font-size: 24px;
      }
      
      .close {
        font-size: 24px;
        margin-top: -5px;
      }
      
      .feature-item {
        font-size: 13px;
      }
      
      .pay-btn {
        width: 100%;
        padding: 10px 20px;
        font-size: 15px;
      }
    }
    
    /* Для маленьких мобильных устройств */
    @media (max-width: 480px) {
      .modal-content {
        padding: 15px 10px;
        margin: 2% auto;
      }
      
      .tariff-card {
        padding: 15px 10px;
      }
      
      .modal-content h2 {
        font-size: 22px;
      }
      
      .tariff-intro {
        font-size: 13px;
        margin-bottom: 15px;
      }
      
      .tariff-features {
        margin: 15px 0;
      }
      
      .feature-item {
        margin-bottom: 8px;
      }
      
      .tariff-note {
        font-size: 12px;
      }
    }
  `;
  document.head.appendChild(modalStyles);

  let currentPage = 1;
  const totalPages = 12;
  let currentLanguage = "ru";

  // --------------------------------------------------
  // 2. Переводы (translations)
  // --------------------------------------------------
    const translations = {
      ru: {
        formTitle: "Заполните анкету",
        name: "Имя",
        phone: "Телефон",
        gender: "Введите имя",
        male: "Я Мужчина",
        female: "Я Женщина",
        country: "Выберите Вашу Страну",
        selectCountry: "-- Выберите страну --",
        region: "Выберите Ваш город",
        selectRegion: "-- Выберите Ваш город --",
        age: "Сколько Вам лет?",
        nationality: "Национальность",
        prayer: "Читаете ли Вы намаз?",
        beard: "Носите ли Вы бороду?",
        quran: "Умеете ли Вы читать К`уран?",
        madhhab: "Ваш Мазхаб?",
        maritalStatus: "Семейное положение",
        children: "Количество детей",
        relocation: "Готовы ли Вы к переезду?",
        desiredWifeAge: "Возраст Будущей жены?",
        character: "Ваш Характер",
        height: "Ваш Рост (в сантиметрах)",
        weight: "Ваш Вес (в килограммах)",
        education: "Образование",
        whatsapp: "Номер в WhatsApp:",
        instagram: "Логин в Instagram:",
        telegram: "Логин в Telegram:",
        aboutMe: "О себе:",
        aboutWife: "О будущей жене:",
        photo: "Загрузите свою фотографию",
        reviewTitle: "Проверьте введённые данные перед отправкой",
        next: "Далее",
        prev: "Назад",
        submit: "Отправить",
        yes: "Да",
        no: "Нет",
        other: "Свой вариант",
        uploadHint: "Или перетяните его из папки в это поле",
        remove: "Удалить",
        phoneMinDigits: "Телефон как минимум 10 цифр",
        kazakhstan: "Казахстан",
        kyrgyzstan: "Киргизия",
        uzbekistan: "Узбекистан",
        russia: "Россия",
        indonesia: "Индонезия",
      },
      kz: {
        formTitle: "Анкетаны толтырыңыз",
        name: "Атыңыз",
        phone: "Телефон",
        gender: "Атыңызды енгізіңіз",
        male: "Мен ер адаммын",
        female: "Мен әйел адаммын",
        country: "Еліңізді таңдаңыз",
        selectCountry: "-- Елді таңдаңыз --",
        region: "Қалаңызды таңдаңыз",
        selectRegion: "-- Қалаңызды таңдаңыз --",
        age: "Жасыңыз қанша?",
        nationality: "Ұлты",
        prayer: "Намаз оқисыз ба?",
        beard: "Сақалыңыз бар ма?",
        quran: "Құран оқи аласыз ба?",
        madhhab: "Мазхабыңыз?",
        maritalStatus: "Отбасылық жағдайы",
        children: "Балалар саны",
        relocation: "Көшуді қарастырасыз ба?",
        desiredWifeAge: "Болашақ жұбайыңыздың жасы?",
        character: "Сипатыңыз",
        height: "Бойыңыз (см)",
        weight: "Салмағыңыз (кг)",
        education: "Білімі",
        whatsapp: "WhatsApp нөірі:",
        instagram: "Instagram логині:",
        telegram: "Telegram логині:",
        aboutMe: "Өзім туралы:",
        aboutWife: "Болашақ жұбайым туралы:",
        photo: "Фотосуретті жүктеңіз",
        reviewTitle: "Жібермес бұрын енгізген деректеріңізді тексеріңіз",
        next: "Келесі",
        prev: "Артқа",
        submit: "Жіберу",
        yes: "Иә",
        no: "Жоқ",
        other: "Өз нұсқаңыз",
        uploadHint: "Немесе файлды осы жерге апарыңыз",
        remove: "Жою",
        phoneMinDigits: "Телефон ең аз дегенде 10 сан болуы керек",
        kazakhstan: "Қазақстан",
        kyrgyzstan: "Қырғызстан",
        uzbekistan: "Өзбекстан",
        russia: "Ресей",
        indonesia: "Индонезия",
      },
      kg: {
        formTitle: "Анкетаны толтуруңуз",
        name: "Атыңыз",
        phone: "Телефон",
        gender: "Атыңызды киргизиңиз",
        male: "Мен эркекмин",
        female: "Мен аялмын",
        country: "Өлкөңүздү тандаңыз",
        selectCountry: "-- Өлкөнү тандаңыз --",
        region: "Шаарыңызды тандаңыз",
        selectRegion: "-- Шаары тандаңыз --",
        age: "Жашыңыз канча?",
        nationality: "Улутуңуз",
        prayer: "Намаз окуйсузбу?",
        beard: "Сакалыңыз барбы?",
        quran: "Куран окуй аласызбы?",
        madhhab: "Мазхабыңыз?",
        maritalStatus: "Үй-бүлөлүк абалы",
        children: "Балдардын саны",
        relocation: "Көчүүгө даярсызбы?",
        desiredWifeAge: "Келген аялыңыздын жашы?",
        character: "Мүнөзүңүз",
        height: "Боюңуз (см)",
        weight: "Салмагыңыз (кг)",
        education: "Билимиңиз",
        whatsapp: "WhatsApp номери:",
        instagram: "Instagram логини:",
        telegram: "Telegram логини:",
        aboutMe: "Өзүм жөнүндө:",
        aboutWife: "Келген аялым жөнүндө:",
        photo: "Сүрөтүңүздү жүктөңүз",
        reviewTitle: "Жөнөтүүдөн мурун киргизген маалыматыңызды текшериңиз",
        next: "Кийинки",
        prev: "Артка",
        submit: "Жөнөтүү",
        yes: "Ооба",
        no: "Жок",
        other: "Өз вариантыңыз",
        uploadHint: "Же файлды бул жерге сүйрөп таштаңыз",
        remove: "Өчүрүү",
        phoneMinDigits: "Телефон кеминде 10 сан болушу керек",
        kazakhstan: "Казакстан",
        kyrgyzstan: "Кыргызстан",
        uzbekistan: "Өзбекстан",
        russia: "Россия",
        indonesia: "Индонезия",
      },
      uz: {
        formTitle: "Anketani to'ldiring",
        name: "Ismingiz",
        phone: "Telefon",
        gender: "Ismingizni kiriting",
        male: "Men erkakman",
        female: "Men ayolman",
        country: "Mamlakatni tanlang",
        selectCountry: "-- Mamlakatni tanlang --",
        region: "Shahringizni tanlang",
        selectRegion: "-- Shaharni tanlang --",
        age: "Yoshingiz nechida?",
        nationality: "Millatingiz",
        prayer: "Namoz o'qiysizmi?",
        beard: "Soqolingiz bormi?",
        quran: "Qur'on o'qiy olasizmi?",
        madhhab: "Mazhabingiz?",
        maritalStatus: "Oilaviy holat",
        children: "Farzandlar soni",
        relocation: "Ko'chishga tayyormisiz?",
        desiredWifeAge: "Kelajakdagi xotiningiz yoshi?",
        character: "Xarakteringiz",
        height: "Bo'yingiz (sm)",
        weight: "Vazningiz (kg)",
        education: "Ma'lumotingiz",
        whatsapp: "WhatsApp raqami:",
        instagram: "Instagram logini:",
        telegram: "Telegram logini:",
        aboutMe: "O'zim haqimda:",
        aboutWife: "Kelajakdagi xotinim haqida:",
        photo: "Suratingizni yuklang",
        reviewTitle: "Yuborishdan oldin kiritilgan ma'lumotlarni tekshiring",
        next: "Keyingi",
        prev: "Orqaga",
        submit: "Yuborish",
        yes: "Ha",
        no: "Yo'q",
        other: "Boshqa variant",
        uploadHint: "Yoki faylni shu yerga sudrab tashlang",
        remove: "O'chirish",
        phoneMinDigits: "Telefon kamida 10 raqam bo'lishi kerak",
        kazakhstan: "Qozog'iston",
        kyrgyzstan: "Qirg'iziston",
        uzbekistan: "O'zbekiston",
        russia: "Rossiya",
        indonesia: "Indoneziya",
      },
      en: {
        formTitle: "Fill out the form",
        name: "Name",
        phone: "Phone",
        gender: "Enter your name",
        male: "I'm Male",
        female: "I'm Female",
        country: "Select your country",
        selectCountry: "-- Select country --",
        region: "Select your city",
        selectRegion: "-- Select your city --",
        age: "How old are you?",
        nationality: "Nationality",
        prayer: "Do you pray?",
        beard: "Do you have a beard?",
        quran: "Can you read Quran?",
        madhhab: "Your Madhhab?",
        maritalStatus: "Marital status",
        children: "Number of children",
        relocation: "Are you ready to relocate?",
        desiredWifeAge: "Desired wife's age?",
        character: "Your character",
        height: "Your height (cm)",
        weight: "Your weight (kg)",
        education: "Education",
        whatsapp: "WhatsApp number:",
        instagram: "Instagram username:",
        telegram: "Telegram username:",
        aboutMe: "About me:",
        aboutWife: "About future wife:",
        photo: "Upload your photo",
        reviewTitle: "Review your information before submitting",
        next: "Next",
        prev: "Back",
        submit: "Submit",
        yes: "Yes",
        no: "No",
        other: "Other",
        uploadHint: "Or drag and drop file here",
        remove: "Remove",
        phoneMinDigits: "Phone must be at least 10 digits",
        kazakhstan: "Kazakhstan",
        kyrgyzstan: "Kyrgyzstan",
        uzbekistan: "Uzbekistan",
        russia: "Russia",
        indonesia: "Indonesia",
      },
      eg: {
        formTitle: "املء الاستمارة",
        name: "الاسم",
        phone: "الهاتف",
        gender: "أدخل اسمك",
        male: "أنا رجل",
        female: "أنا امرأة",
        country: "اختر بلدك",
        selectCountry: "-- اختر البلد --",
        region: "اختر مدينتك",
        selectRegion: "-- اختر المدينة --",
        age: "كم عمرك؟",
        nationality: "الجنسية",
        prayer: "هل تصلي؟",
        beard: "هل لديك لحية؟",
        quran: "هل تستطيع قراءة القرآن؟",
        madhhab: "مذهبك؟",
        maritalStatus: "الحالة الاجتماعية",
        children: "عدد الأطفال",
        relocation: "هل أنت مستعد للانتقال؟",
        desiredWifeAge: "عمر الزوجة المرغوب؟",
        character: "شخصيتك",
        height: "طولك (سم)",
        weight: "وزنك (كجم)",
        education: "التعليم",
        whatsapp: "رقم الواتساب:",
        instagram: "اسم المستخدم في إنستغرام:",
        telegram: "اسم المستخدم في تيليجرام:",
        aboutMe: "عن نفسي:",
        aboutWife: "عن الزوجة المستقبلية:",
        photo: "قم بتحميل صورتك",
        reviewTitle: "راجع معلوماتك قبل الإرسال",
        next: "التالي",
        prev: "السابق",
        submit: "إرسال",
        yes: "نعم",
        no: "لا",
        other: "خيار آخر",
        uploadHint: "أو اسحب الملف وأسقطه هنا",
        remove: "إزالة",
        phoneMinDigits: "يجب أن يحتوي الهاتف على 10 أرقام على الأقل",
        kazakhstan: "كازاخستان",
        kyrgyzstan: "قيرغيزستان",
        uzbekistan: "أوزبكستان",
        russia: "روسيا",
        indonesia: "إندونيسيا",
      },
    };
  
  // --------------------------------------------------
  // 3. Инициализация и обработчики событий
  // --------------------------------------------------
  function initForm() {
    showPage(currentPage);
    updateProgress();
    setupInputListeners();
    updateNavigation();
  }

  // Языковой дропдаун
  selectedLang?.addEventListener("click", function (e) {
      e.stopPropagation();
      langSelector.classList.toggle("active");
    });
    document.addEventListener("click", function () {
      langSelector.classList.remove("active");
    });
    langItems.forEach((item) => {
      item.addEventListener("click", function () {
        const lang = this.dataset.lang;
        const flag = this.querySelector(".flag-icon").innerHTML;
        const name = this.querySelector(".lang-name").textContent;
        selectedLang.querySelector(".flag-icon").innerHTML = flag;
        selectedLang.querySelector(".lang-name").textContent = name;
        langItems.forEach((i) => i.classList.remove("active"));
        this.classList.add("active");
        langSelector.classList.remove("active");
        translatePage(lang);
      });
    });
    languageButtons.forEach((btn) => {
      btn.addEventListener("click", function () {
        languageButtons.forEach((b) => b.classList.remove("active"));
        this.classList.add("active");
        currentLanguage = this.dataset.lang;
        translatePage(currentLanguage);
      });
    });
  
  // Кнопки навигации
  nextBtn?.addEventListener("click", function () {
    if (currentPage === totalPages) {
      submitForm();
    } else {
      goToNextPage();
    }
  });
  prevBtn?.addEventListener("click", function () {
    goToPrevPage();
  });
  submitBtn?.addEventListener("click", submitForm);

  // Кнопки редактирования (на обзоре)
  document.querySelectorAll(".edit-block-btn").forEach((btn) => {
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      const pageToEdit = parseInt(this.dataset.page);
      currentPage = pageToEdit;
      showPage(currentPage);
      updateNavigation();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  });

  // --------------------------------------------------
  // 4. Навигация по страницам
  // --------------------------------------------------
    function showPage(pageNumber) {
      // Удаляем обработчики с предыдущей страницы перед показом новой
      removeValidationListeners(currentPage);

      formPages.forEach((page) => {
        page.classList.remove("active");
        if (parseInt(page.dataset.page) === pageNumber) {
          page.classList.add("active");
        }
      });

      currentPage = pageNumber; // Обновляем текущую страницу здесь

      if (pageNumber === totalPages) {
        populateReviewData();
      }
  
      // Настройка специфичных для страницы элементов (пример: ползунок возраста)
      if (pageNumber === 4) {
        setupAgeSlider();
      }
      
      // Настройка ползунков для желаемого возраста жены
      if (pageNumber === 8) {
        setupWifeAgeSliders();
      }
      
      // Настройка ползунков для роста и веса
      if (pageNumber === 9) {
        setupPhysicalSliders();
      }
      
      // Настройка счетчиков символов для описаний
      if (pageNumber === 11) {
        setupCharCounters();
      }

      // Добавляем обработчики к новой текущей странице
      setupValidationListeners();
      // Обновляем состояние кнопки
      updateNavigation();
    }
    function setupAgeSlider() {
      const ageInput = document.getElementById('age-value');
      const ageSlider = document.getElementById('age');
      if (ageInput && ageSlider) {
        ageInput.value = ageSlider.value;
        ageSlider.removeEventListener('input', handleSliderChange);
        ageInput.removeEventListener('input', handleInputChange);
        ageSlider.addEventListener('input', handleSliderChange);
        ageInput.addEventListener('input', handleInputChange);
        const event = new Event('input');
        ageSlider.dispatchEvent(event);
      }
    }
    function goToNextPage() {
    if (validatePage(currentPage)) {
        currentPage++;
        showPage(currentPage);
        setupInputListeners();
        if (currentPage === 4) {
          const ageInput = document.getElementById('age-value');
          const ageSlider = document.getElementById('age');
          if (ageInput && ageSlider) {
            ageInput.value = ageSlider.value;
          }
        }
        if (currentPage === 8) {
          const minWifeAgeInput = document.getElementById('min-wife-age-value');
          const minWifeAgeSlider = document.getElementById('min-wife-age');
          const maxWifeAgeInput = document.getElementById('max-wife-age-value');
          const maxWifeAgeSlider = document.getElementById('max-wife-age');
          
          if (minWifeAgeInput && minWifeAgeSlider) {
            minWifeAgeInput.value = minWifeAgeSlider.value;
          }
          if (maxWifeAgeInput && maxWifeAgeSlider) {
            maxWifeAgeInput.value = maxWifeAgeSlider.value;
          }
        }
        if (currentPage === 9) {
          const heightInput = document.getElementById('height-value');
          const heightSlider = document.getElementById('height');
          const weightInput = document.getElementById('weight-value');
          const weightSlider = document.getElementById('weight');
          
          if (heightInput && heightSlider) {
            heightInput.value = heightSlider.value;
          }
          if (weightInput && weightSlider) {
            weightInput.value = weightSlider.value;
          }
        }
        window.scrollTo(0, 0);
            } else {
        showNotification(getValidationError(currentPage));
      }
    }
    function goToPrevPage() {
      if (currentPage > 1) {
      currentPage--;
      showPage(currentPage);
        setupInputListeners();
        if (currentPage === 4) {
          const ageInput = document.getElementById('age-value');
          const ageSlider = document.getElementById('age');
          if (ageInput && ageSlider) {
            ageInput.value = ageSlider.value;
          }
        }
        if (currentPage === 8) {
          const minWifeAgeInput = document.getElementById('min-wife-age-value');
          const minWifeAgeSlider = document.getElementById('min-wife-age');
          const maxWifeAgeInput = document.getElementById('max-wife-age-value');
          const maxWifeAgeSlider = document.getElementById('max-wife-age');
          
          if (minWifeAgeInput && minWifeAgeSlider) {
            minWifeAgeInput.value = minWifeAgeSlider.value;
          }
          if (maxWifeAgeInput && maxWifeAgeSlider) {
            maxWifeAgeInput.value = maxWifeAgeSlider.value;
          }
        }
        if (currentPage === 9) {
          const heightInput = document.getElementById('height-value');
          const heightSlider = document.getElementById('height');
          const weightInput = document.getElementById('weight-value');
          const weightSlider = document.getElementById('weight');
          
          if (heightInput && heightSlider) {
            heightInput.value = heightSlider.value;
          }
          if (weightInput && weightSlider) {
            weightInput.value = weightSlider.value;
          }
        }
        window.scrollTo(0, 0);
      }
    }
    function updateNavigation() {
      prevBtn.style.display = currentPage === 1 ? "none" : "inline-block";
      prevBtn.disabled = currentPage === 1;
    nextBtn.textContent = currentPage === totalPages ? "Отправить анкету" : translations[currentLanguage].next || "Далее";
    nextBtn.disabled = !isCurrentPageValid();
    // Прогресс-бар
    const progress = ((currentPage - 1) / (totalPages - 1)) * 100;
    progressBar.style.width = `${progress}%`;
    progressText.textContent = `Готово: ${currentPage - 1} / ${totalPages - 1}`;
  }

  // --------------------------------------------------
  // 5. Валидация
  // --------------------------------------------------
  function validatePage(pageNumber) {
    const currentPageElement = document.querySelector(`.form-page[data-page="${pageNumber}"]`);
    if (!currentPageElement) return false;
    
    const errorMessage = getValidationError(pageNumber);
    if (errorMessage) {
      showNotification(errorMessage);
      return false;
    }
    
    return true;
  }
  function isCurrentPageValid() {
    // Можно реализовать более строгую проверку для блокировки кнопки "Далее"
    return validatePage(currentPage);
  }

  // --------------------------------------------------
  // 6. Заполнение обзора (review)
  // --------------------------------------------------
    function populateReviewData() {
    // Страница 1: Имя и телефон
    const nameElement = document.getElementById("name");
    const phoneElement = document.getElementById("phone");
    if (nameElement && document.getElementById("review-name")) {
      document.getElementById("review-name").textContent = nameElement.value || "Не указано";
    }
    if (phoneElement && document.getElementById("review-phone")) {
      document.getElementById("review-phone").textContent = phoneElement.value || "Не указано";
    }
    
    // Страница 2: Пол и страна
    const genderRadio = document.querySelector('input[name="gender"]:checked');
    if (genderRadio && document.getElementById("review-gender")) {
      document.getElementById("review-gender").textContent = genderRadio.value === "male" ? "Мужчина" : "Женщина";
    }
    
    const countryElement = document.getElementById("country");
    if (countryElement && document.getElementById("review-country")) {
      const selectedOption = countryElement.options[countryElement.selectedIndex];
      document.getElementById("review-country").textContent = selectedOption ? selectedOption.textContent : "Не указано";
    }
    
    // Страница 3: Город
    const regionElement = document.getElementById("region");
    if (regionElement && document.getElementById("review-region")) {
      document.getElementById("review-region").textContent = regionElement.value || "Не указано";
    }
    
    // Страница 4: Возраст
    const ageElement = document.getElementById("age");
    if (ageElement && document.getElementById("review-age")) {
      document.getElementById("review-age").textContent = ageElement.value + " лет" || "Не указано";
    }
    
    // Страница 5: Национальность, намаз, борода
    const nationalityElement = document.getElementById("nationality");
    if (nationalityElement && document.getElementById("review-nationality")) {
      let nationalityText = nationalityElement.value;
      if (nationalityElement.value === "other") {
        const otherNationalityElement = document.getElementById("other-nationality");
        if (otherNationalityElement) {
          nationalityText = otherNationalityElement.value;
        }
      } else if (nationalityElement.selectedIndex > 0) {
        nationalityText = nationalityElement.options[nationalityElement.selectedIndex].textContent;
      }
      document.getElementById("review-nationality").textContent = nationalityText || "Не указано";
    }
    
    const prayerRadio = document.querySelector('input[name="prayer"]:checked');
    if (prayerRadio && document.getElementById("review-prayer")) {
      let prayerText = prayerRadio.value === "yes" ? "Да" : "Нет";
      if (prayerRadio.id === "prayer-other-radio") {
        const otherPrayerElement = document.getElementById("prayer-other-input");
        if (otherPrayerElement) {
          prayerText = otherPrayerElement.value;
        }
      }
      document.getElementById("review-prayer").textContent = prayerText || "Не указано";
    }
    
    const beardRadio = document.querySelector('input[name="beard"]:checked');
    if (beardRadio && document.getElementById("review-beard")) {
      let beardText = beardRadio.value === "yes" ? "Да" : "Нет";
      if (beardRadio.id === "beard-other-radio") {
        const otherBeardElement = document.getElementById("beard-other-input");
        if (otherBeardElement) {
          beardText = otherBeardElement.value;
        }
      }
      document.getElementById("review-beard").textContent = beardText || "Не указано";
    }
    
    // Страница 6: Коран, мазхаб, семейное положение
    const quranRadio = document.querySelector('input[name="quran"]:checked');
    if (quranRadio && document.getElementById("review-quran")) {
      let quranText = quranRadio.value === "yes" ? "Да" : "Нет";
      if (quranRadio.id === "quran-other-radio") {
        const otherQuranElement = document.getElementById("quran-other-input");
        if (otherQuranElement) {
          quranText = otherQuranElement.value;
        }
      }
      document.getElementById("review-quran").textContent = quranText || "Не указано";
    }
    
    const madhabElement = document.getElementById("madhhab");
    if (madhabElement && document.getElementById("review-madhhab")) {
      document.getElementById("review-madhhab").textContent = madhabElement.value || "Не указано";
    }
    
    const maritalStatusElement = document.getElementById("marital-status");
    if (maritalStatusElement && document.getElementById("review-marital-status")) {
      document.getElementById("review-marital-status").textContent = maritalStatusElement.value || "Не указано";
    }
    
    // Страница 7: Дети и переезд
    const childrenElement = document.getElementById("children");
    if (childrenElement && document.getElementById("review-children")) {
      let childrenText = childrenElement.value;
      if (childrenElement.value === "other") {
        const otherChildrenElement = document.getElementById("other-children");
        if (otherChildrenElement) {
          childrenText = otherChildrenElement.value;
        }
      } else if (childrenElement.selectedIndex > 0) {
        childrenText = childrenElement.options[childrenElement.selectedIndex].textContent;
      }
      document.getElementById("review-children").textContent = childrenText || "Не указано";
    }
    
    const relocationRadio = document.querySelector('input[name="relocation"]:checked');
    if (relocationRadio && document.getElementById("review-relocation")) {
      let relocationText = relocationRadio.value === "yes" ? "Да" : "Нет";
      if (relocationRadio.id === "relocation-other-radio") {
        const otherRelocationElement = document.getElementById("relocation-other-input");
        if (otherRelocationElement && otherRelocationElement.style.display !== 'none') {
          relocationText = otherRelocationElement.value;
        }
      }
      document.getElementById("review-relocation").textContent = relocationText || "Не указано";
    }
    
    // Страница 8: Желаемый возраст и характер
    const minWifeAge = document.getElementById("min-wife-age");
    const maxWifeAge = document.getElementById("max-wife-age");
    if (minWifeAge && maxWifeAge && document.getElementById("review-desired-age")) {
      document.getElementById("review-desired-age").textContent = `${minWifeAge.value} - ${maxWifeAge.value} лет`;
    }
    
    const characterElement = document.getElementById("character");
    if (characterElement && document.getElementById("review-character")) {
      document.getElementById("review-character").textContent = characterElement.value || "Не указано";
    }
    
    // Страница 9: Рост, вес, образование
    const heightElement = document.getElementById("height");
    if (heightElement && document.getElementById("review-height")) {
      document.getElementById("review-height").textContent = `${heightElement.value} см`;
    }
    
    const weightElement = document.getElementById("weight");
    if (weightElement && document.getElementById("review-weight")) {
      document.getElementById("review-weight").textContent = `${weightElement.value} кг`;
    }
    
    const educationElement = document.getElementById("education");
    if (educationElement && document.getElementById("review-education")) {
      let educationText = educationElement.value;
      if (educationElement.value === "other") {
        const otherEducationElement = document.getElementById("other-education");
        if (otherEducationElement) {
          educationText = otherEducationElement.value;
        }
      } else if (educationElement.selectedIndex > 0) {
        educationText = educationElement.options[educationElement.selectedIndex].textContent;
      }
      document.getElementById("review-education").textContent = educationText || "Не указано";
    }
    
    // Страница 10: Контактная информация
    const whatsappElement = document.getElementById("whatsapp");
    if (whatsappElement && document.getElementById("review-whatsapp")) {
      document.getElementById("review-whatsapp").textContent = whatsappElement.value || "Не указано";
    }
    
    const instagramElement = document.getElementById("instagram");
    if (instagramElement && document.getElementById("review-instagram")) {
      document.getElementById("review-instagram").textContent = instagramElement.value || "Не указано";
    }
    
    const telegramElement = document.getElementById("telegram");
    if (telegramElement && document.getElementById("review-telegram")) {
      document.getElementById("review-telegram").textContent = telegramElement.value || "Не указано";
    }
    
    // Страница 11: О себе, о будущей жене, фотография
    const aboutMeElement = document.getElementById("about-me");
    if (aboutMeElement && document.getElementById("review-about-me")) {
      document.getElementById("review-about-me").textContent = aboutMeElement.value || "Не указано";
    }
    
    const aboutWifeElement = document.getElementById("about-wife");
    if (aboutWifeElement && document.getElementById("review-about-wife")) {
      document.getElementById("review-about-wife").textContent = aboutWifeElement.value || "Не указано";
    }
    
    const photoElement = document.getElementById("photo");
    if (photoElement && document.getElementById("review-photo")) {
      const hasFile = photoElement.files && photoElement.files.length > 0;
      document.getElementById("review-photo").textContent = hasFile ? photoElement.files[0].name : "Фото не загружено";
    }
  }

  // --------------------------------------------------
  // 7. Отправка формы
  // --------------------------------------------------
    function submitForm() {
    if (!validatePage(currentPage)) {
      showNotification(getValidationError(currentPage));
      return;
    }
    
    // Отображаем модальное окно с тарифами вместо отправки формы
    const modal = document.getElementById('tariffs-modal');
    if (modal) {
    modal.style.display = 'block';
    
    // Обработчик закрытия модального окна при клике на крестик
    const closeBtn = modal.querySelector('.close');
      if (closeBtn) {
    closeBtn.onclick = function() {
      modal.style.display = 'none';
    };
      }
    
    // Закрытие модального окна при клике вне его области
    window.onclick = function(event) {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    };
    
    // Добавляем обработчики событий для кнопок оплаты
    const payButtons = modal.querySelectorAll('.pay-btn');
    payButtons.forEach(button => {
      button.onclick = function() {
        // Собираем данные формы
        const formData = new FormData();
        
        // Получаем все поля формы
        formData.append('name', document.getElementById('name').value);
        formData.append('phone', document.getElementById('phone').value);
        formData.append('gender', document.querySelector('input[name="gender"]:checked')?.value || '');
        formData.append('country', document.getElementById('country').value);
        formData.append('region', document.getElementById('region').value);
        formData.append('age', document.getElementById('age').value);
        formData.append('nationality', document.getElementById('nationality').value);
        formData.append('prayer', document.querySelector('input[name="prayer"]:checked')?.value || '');
        
        // Поле борода может отсутствовать для женщин
        const beardRadio = document.querySelector('input[name="beard"]:checked');
        if (beardRadio) {
          formData.append('beard', beardRadio.value);
        }
        
        formData.append('quran', document.querySelector('input[name="quran"]:checked')?.value || '');
        
        if (document.getElementById('madhhab')) {
          formData.append('madhhab', document.getElementById('madhhab').value);
        }
        
        if (document.getElementById('marital-status')) {
          formData.append('marital_status', document.getElementById('marital-status').value);
        }
        
        if (document.getElementById('children')) {
          formData.append('children', document.getElementById('children').value);
        }
        
        formData.append('relocation', document.querySelector('input[name="relocation"]:checked')?.value || '');
        
        // Поля для мужчин при поиске жены
        if (document.getElementById('min-wife-age')) {
          formData.append('min_wife_age', document.getElementById('min-wife-age').value);
        }
        
        if (document.getElementById('max-wife-age')) {
          formData.append('max_wife_age', document.getElementById('max-wife-age').value);
        }
        
        if (document.getElementById('character')) {
          formData.append('character', document.getElementById('character').value);
        }
        
        formData.append('height', document.getElementById('height').value);
        formData.append('weight', document.getElementById('weight').value);
        formData.append('education', document.getElementById('education').value);
        formData.append('whatsapp', document.getElementById('whatsapp').value);
        formData.append('instagram', document.getElementById('instagram').value);
        formData.append('telegram', document.getElementById('telegram').value);
        formData.append('about_me', document.getElementById('about-me').value);
        
        // Поле о жене может отсутствовать для женщин
        const aboutWife = document.getElementById('about-wife');
        if (aboutWife) {
          formData.append('about_wife', aboutWife.value);
        }
        
        // Фотография если есть
        const photoInput = document.getElementById('photo');
        if (photoInput && photoInput.files && photoInput.files.length > 0) {
          formData.append('photo', photoInput.files[0]);
        }
        
        // Добавляем информацию о выбранном тарифе
        formData.append('tariff', this.getAttribute('data-tariff'));
        
        // Получаем CSRF-токен
        const csrftoken = getCookie('csrftoken');
        
        // Выводим логи для отладки
        console.log('Отправляем данные формы:', {
          name: document.getElementById('name').value,
          phone: document.getElementById('phone').value,
          gender: document.querySelector('input[name="gender"]:checked')?.value,
          tariff: this.getAttribute('data-tariff')
        });
        
        // Отображаем сообщение о загрузке
        showNotification('Отправка анкеты...');
        
        // Отправляем данные на сервер
        fetch('/submit-profile/', {
          method: 'POST',
          headers: {
            'X-CSRFToken': csrftoken
          },
          body: formData
        })
        .then(response => {
          console.log('Получен ответ от сервера:', response.status);
          return response.json().catch(err => {
            console.error('Ошибка при парсинге JSON:', err);
            throw new Error('Ошибка при обработке ответа сервера');
          });
        })
        .then(data => {
          console.log('Обработанные данные:', data);
          if (data.success) {
            // После успешной отправки показываем сообщение и переходим на страницу оплаты
            showNotification('Анкета успешно отправлена! Перенаправление на страницу оплаты...');
            setTimeout(() => {
              window.location.href = 'https://pay.kaspi.kz/pay/jgs5i3yk';
            }, 1500);
          } else {
            // Если произошла ошибка, показываем сообщение
            showNotification(data.message || 'Произошла ошибка при отправке анкеты');
          }
        })
        .catch(error => {
          console.error('Ошибка при отправке:', error);
          showNotification('Произошла ошибка при отправке анкеты. Попробуйте еще раз.');
        });
      };
    });
    } else {
      console.error('Модальное окно с тарифами не найдено!');
    }
  }

  // --------------------------------------------------
  // 8. Вспомогательные функции
  // --------------------------------------------------

  // Обновление счетчиков символов для текстовых полей
  function setupCharCounters() {
    const aboutMeTextarea = document.getElementById('about-me');
    const aboutWifeTextarea = document.getElementById('about-wife');
    const aboutMeCounter = document.getElementById('about-me-counter');
    const aboutWifeCounter = document.getElementById('about-wife-counter');
    
    function updateCounter(textarea, counter) {
      if (textarea && counter) {
        const length = textarea.value.trim().length;
        counter.textContent = length;
        
        const counterElement = counter.parentElement;
        if (length >= 30) {
          counterElement.classList.add('valid');
          counterElement.classList.remove('invalid');
        } else {
          counterElement.classList.add('invalid');
          counterElement.classList.remove('valid');
        }
      }
    }
    
    if (aboutMeTextarea && aboutMeCounter) {
      updateCounter(aboutMeTextarea, aboutMeCounter);
      aboutMeTextarea.addEventListener('input', function() {
        updateCounter(this, aboutMeCounter);
      });
    }
    
    if (aboutWifeTextarea && aboutWifeCounter) {
      updateCounter(aboutWifeTextarea, aboutWifeCounter);
      aboutWifeTextarea.addEventListener('input', function() {
        updateCounter(this, aboutWifeCounter);
      });
    }
  }

  function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim();
        if (cookie.substring(0, name.length + 1) === (name + '=')) {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
        }
      }
    }
    return cookieValue;
  }

    function setupInputListeners() {
    // Пример: для синхронизации возраста
    const ageInput = document.getElementById('age-value');
    const ageSlider = document.getElementById('age');
    if (ageInput && ageSlider) {
      ageSlider.addEventListener('input', () => {
        ageInput.value = ageSlider.value;
      });
      ageInput.addEventListener('input', () => {
        let val = parseInt(ageInput.value);
        if (!isNaN(val) && val >= 18 && val <= 65) {
          ageSlider.value = val;
        }
      });
    }
    
    // Обработчик для показа поля ввода своего города
    const regionSelect = document.getElementById('region');
    const customCityGroup = document.getElementById('customCityGroup');
    
    if (regionSelect && customCityGroup) {
      regionSelect.addEventListener('change', function() {
        if (this.value === 'Другая' || this.value === 'Свой вариант') {
          customCityGroup.style.display = 'block';
        } else {
          customCityGroup.style.display = 'none';
        }
      });
      
      // Вызовем изменение сразу, если значение уже выбрано
      if (regionSelect.value === 'Другая' || regionSelect.value === 'Свой вариант') {
        customCityGroup.style.display = 'block';
      }
    }
    
    // Аналогичные обработчики для других "Свой вариант" полей
    setupOtherInputHandlers();

    // Инициализируем счетчики символов для текстовых полей
    if (currentPage === 11) {
      setupCharCounters();
    }
  }

  function setupOtherInputHandlers() {
    // Национальность
    const nationalitySelect = document.getElementById('nationality');
    const otherNationalityInput = document.getElementById('other-nationality');
    if (nationalitySelect && otherNationalityInput) {
      nationalitySelect.addEventListener('change', function() {
        otherNationalityInput.style.display = this.value === 'other' ? 'block' : 'none';
      });
    }
    
    // Мазхаб
    const madhabSelect = document.getElementById('madhhab');
    const otherMadhabInput = document.getElementById('other-madhhab');
    if (madhabSelect && otherMadhabInput) {
      madhabSelect.addEventListener('change', function() {
        otherMadhabInput.style.display = this.value === 'other' ? 'block' : 'none';
      });
    }
    
    // Семейное положение
    const maritalStatusSelect = document.getElementById('marital-status');
    const otherMaritalStatusInput = document.getElementById('other-marital-status');
    if (maritalStatusSelect && otherMaritalStatusInput) {
      maritalStatusSelect.addEventListener('change', function() {
        otherMaritalStatusInput.style.display = this.value === 'other' ? 'block' : 'none';
      });
    }
    
    // Дети
    const childrenSelect = document.getElementById('children');
    const otherChildrenInput = document.getElementById('other-children');
    if (childrenSelect && otherChildrenInput) {
      childrenSelect.addEventListener('change', function() {
        otherChildrenInput.style.display = this.value === 'other' ? 'block' : 'none';
      });
    }
    
    // Радио-кнопки с опцией "Свой вариант"
    setupRadioOtherHandlers('prayer', 'prayer-other-radio', 'prayer-other-input');
    setupRadioOtherHandlers('beard', 'beard-other-radio', 'beard-other-input');
    setupRadioOtherHandlers('quran', 'quran-other-radio', 'quran-other-input');
    setupRadioOtherHandlers('relocation', 'relocation-other-radio', 'relocation-other-input');
  }

  function setupRadioOtherHandlers(radioGroupName, otherRadioId, otherInputId) {
    const radioButtons = document.querySelectorAll(`input[name="${radioGroupName}"]`);
    const otherInput = document.getElementById(otherInputId);
    
    if (radioButtons.length && otherInput) {
      radioButtons.forEach(radio => {
        radio.addEventListener('change', function() {
          otherInput.style.display = this.id === otherRadioId ? 'block' : 'none';
      });
    });
  
      // Проверяем начальное состояние
      const otherRadio = document.getElementById(otherRadioId);
      if (otherRadio && otherRadio.checked) {
        otherInput.style.display = 'block';
      }
    }
  }

  // Навешиваем обработчики
  function setupValidationListeners() {
    const currentPageElement = document.querySelector(`.form-page[data-page="${currentPage}"]`);
    if (!currentPageElement) return;
    const inputs = currentPageElement.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
      // Используем именованные функции для возможности удаления
      input.addEventListener('input', handleValidationTrigger);
      input.addEventListener('change', handleValidationTrigger);
    });
  }

  // Удаляем обработчики
  function removeValidationListeners(pageNumber) {
    const pageElement = document.querySelector(`.form-page[data-page="${pageNumber}"]`);
    if (!pageElement) return;
    const inputs = pageElement.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
      input.removeEventListener('input', handleValidationTrigger);
      input.removeEventListener('change', handleValidationTrigger);
    });
  }

  // Общий обработчик для запуска валидации
  function handleValidationTrigger() {
      updateNavigation();
  }

  // --------------------------------------------------
  // 9. Запуск и инициализация
  // --------------------------------------------------
    initForm();

  function translatePage(lang) {
    const translation = translations[lang];
    if (!translation) return;
    console.log('Переводим на язык:', lang);
    document.querySelectorAll('[data-translate]').forEach(el => {
      const key = el.dataset.translate;
      if (translation[key]) el.textContent = translation[key];
    });
    document.querySelectorAll('[data-placeholder]').forEach(el => {
      const key = el.dataset.placeholder;
      if (translation[key]) el.placeholder = translation[key];
    });
    document.querySelectorAll('option[data-option]').forEach(option => {
      const key = option.dataset.option;
      if (translation[key]) option.textContent = translation[key];
    });
  }

  // Выносим функции обработчики чтобы можно было их удалять по имени
  function handleSliderChange(e) {
    const ageInput = document.getElementById('age-value');
    if (ageInput) {
      ageInput.value = e.target.value;
    }
  }

  function handleInputChange(e) {
  const ageSlider = document.getElementById('age');
    if (ageSlider) {
      let val = parseInt(e.target.value);
      if (!isNaN(val) && val >= 18 && val <= 65) {
          ageSlider.value = val;
      }
    }
  }

  // Кастомное уведомление
  function showNotification(message) {
    // Удаляем старое модальное окно, если оно есть
    let oldBg = document.getElementById('modal-notification-bg');
    if (oldBg) oldBg.remove();

    // Создаем затемнённый фон
    const bg = document.createElement('div');
    bg.className = 'modal-notification-bg';
    bg.id = 'modal-notification-bg';

    // Создаем само окно
    const modal = document.createElement('div');
    modal.className = 'modal-notification';
    modal.textContent = message;

    bg.appendChild(modal);
    document.body.appendChild(bg);

    // Автоматическое закрытие через 2 секунды
    setTimeout(() => {
      bg.classList.add('fade-out');
      modal.classList.add('fade-out');
      setTimeout(() => {
        bg.remove();
      }, 300);
    }, 2000);
  }

  // Функция для получения текста ошибки для каждой страницы
  function getValidationError(pageNumber) {
    switch (pageNumber) {
      case 1:
        const name = document.getElementById("name");
        const phone = document.getElementById("phone");
        if (!name || !name.value.trim()) return "Пожалуйста, введите ваше имя";
        if (!phone || !phone.value.trim() || phone.value.replace(/\D/g, '').length < 10) return "Телефон как минимум 10 цифр";
        break;
      case 2:
        const gender = document.querySelector('input[name="gender"]:checked');
        const country = document.getElementById("country");
        if (!gender) return "Пожалуйста, выберите ваш пол";
        if (!country || !country.value) return "Пожалуйста, выберите вашу страну";
        break;
      case 3:
        const region = document.getElementById("region");
        if (!region || !region.value) return "Пожалуйста, выберите ваш город";
        if (region.value === "Другая") {
          const customCity = document.getElementById("customCity");
          if (!customCity || !customCity.value.trim()) return "Пожалуйста, введите ваш город";
        }
        break;
      case 4:
        const age = document.getElementById("age");
        if (!age || !age.value || age.value < 18 || age.value > 65) return "Пожалуйста, введите корректный возраст (18-65)";
        break;
      case 5:
        const nationality = document.getElementById("nationality");
        if (!nationality || !nationality.value) return "Пожалуйста, выберите вашу национальность";
        if (nationality.value === "other") {
          const otherNationality = document.getElementById("other-nationality");
          if (!otherNationality || !otherNationality.value.trim()) return "Пожалуйста, введите вашу национальность";
        }
        
        const prayer = document.querySelector('input[name="prayer"]:checked');
        if (!prayer) return "Пожалуйста, укажите читаете ли вы намаз";
        if (prayer.id === "prayer-other-radio") {
          const otherPrayer = document.getElementById("prayer-other-input");
          if (!otherPrayer || !otherPrayer.value.trim()) return "Пожалуйста, заполните поле 'Свой вариант' для намаза";
        }
        
        const beard = document.querySelector('input[name="beard"]:checked');
        if (!beard) return "Пожалуйста, укажите носите ли вы бороду";
        if (beard.id === "beard-other-radio") {
          const otherBeard = document.getElementById("beard-other-input");
          if (!otherBeard || !otherBeard.value.trim()) return "Пожалуйста, заполните поле 'Свой вариант' для бороды";
        }
        break;
      case 6:
        const quran = document.querySelector('input[name="quran"]:checked');
        if (!quran) return "Пожалуйста, укажите умеете ли вы читать Коран";
        if (quran.id === "quran-other-radio") {
          const otherQuran = document.getElementById("quran-other-input");
          if (!otherQuran || !otherQuran.value.trim()) return "Пожалуйста, заполните поле 'Свой вариант' для Корана";
        }
        
        const madhhab = document.getElementById("madhhab");
        if (!madhhab || !madhhab.value) return "Пожалуйста, выберите ваш мазхаб";
        if (madhhab.value === "other") {
          const otherMadhhab = document.getElementById("other-madhhab");
          if (!otherMadhhab || !otherMadhhab.value.trim()) return "Пожалуйста, введите ваш мазхаб";
        }
        
        const maritalStatus = document.getElementById("marital-status");
        if (!maritalStatus || !maritalStatus.value) return "Пожалуйста, выберите ваше семейное положение";
        if (maritalStatus.value === "other") {
          const otherMaritalStatus = document.getElementById("other-marital-status");
          if (!otherMaritalStatus || !otherMaritalStatus.value.trim()) return "Пожалуйста, введите ваше семейное положение";
        }
        break;
      case 7:
        const children = document.getElementById("children");
        if (!children || !children.value) return "Пожалуйста, укажите количество детей";
        if (children.value === "other") {
          const otherChildren = document.getElementById("other-children");
          if (!otherChildren || !otherChildren.value.trim()) return "Пожалуйста, введите количество детей";
        }
        
        const relocation = document.querySelector('input[name="relocation"]:checked');
        if (!relocation) return "Пожалуйста, укажите готовы ли вы к переезду";
        if (relocation.id === "relocation-other-radio") {
          const otherRelocation = document.getElementById("relocation-other-input");
          if (!otherRelocation || !otherRelocation.value.trim()) return "Пожалуйста, заполните поле 'Свой вариант' для переезда";
        }
        break;
      case 8:
        const minAge = document.getElementById("min-wife-age");
        if (!minAge || !minAge.value || isNaN(parseInt(minAge.value))) return "Пожалуйста, введите желаемый минимальный возраст жены";
        
        const maxAge = document.getElementById("max-wife-age");
        if (!maxAge || !maxAge.value || isNaN(parseInt(maxAge.value))) return "Пожалуйста, введите желаемый максимальный возраст жены";
        
        if (parseInt(minAge.value) > parseInt(maxAge.value)) return "Минимальный возраст не может быть больше максимального";
        
        const character = document.getElementById("character");
        if (!character || !character.value.trim()) return "Пожалуйста, опишите ваш характер";
        break;
      case 9:
        const height = document.getElementById("height");
        if (!height || !height.value || isNaN(parseInt(height.value)) || parseInt(height.value) < 150 || parseInt(height.value) > 220) 
          return "Пожалуйста, введите корректный рост (150-220 см)";
        
        const weight = document.getElementById("weight");
        if (!weight || !weight.value || isNaN(parseInt(weight.value)) || parseInt(weight.value) < 45 || parseInt(weight.value) > 150) 
          return "Пожалуйста, введите корректный вес (45-150 кг)";
        
        const education = document.getElementById("education");
        if (!education || !education.value) return "Пожалуйста, выберите ваше образование";
        break;
      case 10:
        const whatsapp = document.getElementById("whatsapp");
        if (!whatsapp || !whatsapp.value.trim()) return "Пожалуйста, введите ваш номер WhatsApp";
        
        const instagram = document.getElementById("instagram");
        if (!instagram || !instagram.value.trim()) return "Пожалуйста, введите ваш Instagram";
        
        const telegram = document.getElementById("telegram");
        if (!telegram || !telegram.value.trim()) return "Пожалуйста, введите ваш Telegram";
        break;
      case 11:
        const aboutMe = document.getElementById("about-me");
        if (!aboutMe || !aboutMe.value.trim()) {
          return "Пожалуйста, расскажите о себе";
        }
        if (aboutMe.value.trim().length < 30) {
          return "Рассказ о себе должен содержать не менее 30 символов";
        }
        
        const aboutWife = document.getElementById("about-wife");
        if (!aboutWife || !aboutWife.value.trim()) {
          return "Пожалуйста, расскажите о будущей жене";
        }
        if (aboutWife.value.trim().length < 30) {
          return "Рассказ о будущей жене должен содержать не менее 30 символов";
        }
        
        break;
      default:
        return null;
    }
    return null;
  }

  // Ползунки для желаемого возраста жены (страница 8)
  function setupWifeAgeSliders() {
    // Минимальный возраст жены
    const minWifeAgeInput = document.getElementById('min-wife-age-value');
    const minWifeAgeSlider = document.getElementById('min-wife-age');
    const maxWifeAgeInput = document.getElementById('max-wife-age-value');
    const maxWifeAgeSlider = document.getElementById('max-wife-age');
    
    if (minWifeAgeInput && minWifeAgeSlider && maxWifeAgeInput && maxWifeAgeSlider) {
      // Устанавливаем начальные значения
      minWifeAgeInput.value = minWifeAgeSlider.value;
      maxWifeAgeInput.value = maxWifeAgeSlider.value;
      
      // Удаляем существующие обработчики, если они есть
      minWifeAgeSlider.removeEventListener('input', handleMinWifeAgeSliderChange);
      minWifeAgeInput.removeEventListener('input', handleMinWifeAgeInputChange);
      maxWifeAgeSlider.removeEventListener('input', handleMaxWifeAgeSliderChange);
      maxWifeAgeInput.removeEventListener('input', handleMaxWifeAgeInputChange);
      
      // Добавляем новые обработчики
      minWifeAgeSlider.addEventListener('input', handleMinWifeAgeSliderChange);
      minWifeAgeInput.addEventListener('input', handleMinWifeAgeInputChange);
      maxWifeAgeSlider.addEventListener('input', handleMaxWifeAgeSliderChange);
      maxWifeAgeInput.addEventListener('input', handleMaxWifeAgeInputChange);
      
      // Инициализируем событие для обновления значений
      const event = new Event('input');
      minWifeAgeSlider.dispatchEvent(event);
      maxWifeAgeSlider.dispatchEvent(event);
    }
  }
  
  function handleMinWifeAgeSliderChange(e) {
    const minWifeAgeInput = document.getElementById('min-wife-age-value');
    const maxWifeAgeSlider = document.getElementById('max-wife-age');
    if (minWifeAgeInput) {
      minWifeAgeInput.value = e.target.value;
    }

    if (maxWifeAgeSlider && parseInt(e.target.value) > parseInt(maxWifeAgeSlider.value)) {
      maxWifeAgeSlider.value = e.target.value;
      const maxWifeAgeInput = document.getElementById('max-wife-age-value');
      if (maxWifeAgeInput) {
        maxWifeAgeInput.value = e.target.value;
      }
    }
  }
  
  function handleMinWifeAgeInputChange(e) {
    const minWifeAgeSlider = document.getElementById('min-wife-age');
    const maxWifeAgeSlider = document.getElementById('max-wife-age');
    const maxWifeAgeInput = document.getElementById('max-wife-age-value');
    if (minWifeAgeSlider) {
      let val = parseInt(e.target.value);
      if (!isNaN(val) && val >= 18 && val <= 65) {
        minWifeAgeSlider.value = val;
        // Если минимальный возраст больше максимального, обновляем максимальный
        if (maxWifeAgeSlider && parseInt(val) > parseInt(maxWifeAgeSlider.value)) {
          maxWifeAgeSlider.value = val;
          if (maxWifeAgeInput) {
            maxWifeAgeInput.value = val;
          }
        }
      }
    }
  }
  
  function handleMaxWifeAgeSliderChange(e) {
    const maxWifeAgeInput = document.getElementById('max-wife-age-value');
    const minWifeAgeSlider = document.getElementById('min-wife-age');
    if (maxWifeAgeInput) {
      maxWifeAgeInput.value = e.target.value;
    }
    // Убедимся, что максимальный возраст не меньше минимального
    if (minWifeAgeSlider && parseInt(e.target.value) < parseInt(minWifeAgeSlider.value)) {
      minWifeAgeSlider.value = e.target.value;
      const minWifeAgeInput = document.getElementById('min-wife-age-value');
      if (minWifeAgeInput) {
        minWifeAgeInput.value = e.target.value;
      }
    }
  }
  
  function handleMaxWifeAgeInputChange(e) {
    const maxWifeAgeSlider = document.getElementById('max-wife-age');
    const minWifeAgeSlider = document.getElementById('min-wife-age');
    const minWifeAgeInput = document.getElementById('min-wife-age-value');
    if (maxWifeAgeSlider) {
      let val = parseInt(e.target.value);
      if (!isNaN(val) && val >= 18 && val <= 65) {
        maxWifeAgeSlider.value = val;
        // Если максимальный возраст меньше минимального, обновляем минимальный
        if (minWifeAgeSlider && parseInt(val) < parseInt(minWifeAgeSlider.value)) {
          minWifeAgeSlider.value = val;
          if (minWifeAgeInput) {
            minWifeAgeInput.value = val;
          }
        }
      }
    }
  }

  // Ползунки для физических данных (страница 9)
  function setupPhysicalSliders() {
    // Настройка ползунка для роста
    const heightInput = document.getElementById('height-value');
    const heightSlider = document.getElementById('height');
    const weightInput = document.getElementById('weight-value');
    const weightSlider = document.getElementById('weight');
    
    if (heightInput && heightSlider && weightInput && weightSlider) {
      // Устанавливаем начальные значения
      heightInput.value = heightSlider.value;
      weightInput.value = weightSlider.value;
      
      // Удаляем существующие обработчики, если они есть
      heightSlider.removeEventListener('input', handleHeightSliderChange);
      heightInput.removeEventListener('input', handleHeightInputChange);
      weightSlider.removeEventListener('input', handleWeightSliderChange);
      weightInput.removeEventListener('input', handleWeightInputChange);
      
      // Добавляем новые обработчики
      heightSlider.addEventListener('input', handleHeightSliderChange);
      heightInput.addEventListener('input', handleHeightInputChange);
      weightSlider.addEventListener('input', handleWeightSliderChange);
      weightInput.addEventListener('input', handleWeightInputChange);
      
      // Инициализируем событие для обновления значений
      const event = new Event('input');
      heightSlider.dispatchEvent(event);
      weightSlider.dispatchEvent(event);
    }
  }
  
  function handleHeightSliderChange(e) {
    const heightInput = document.getElementById('height-value');
    if (heightInput) {
      heightInput.value = e.target.value;
    }
  }
  
  function handleHeightInputChange(e) {
    const heightSlider = document.getElementById('height');
    if (heightSlider) {
      let val = parseInt(e.target.value);
    if (!isNaN(val) && val >= 150 && val <= 220) {
        heightSlider.value = val;
      }
    }
  }
  
  function handleWeightSliderChange(e) {
    const weightInput = document.getElementById('weight-value');
    if (weightInput) {
      weightInput.value = e.target.value;
    }
  }
  
  function handleWeightInputChange(e) {
    const weightSlider = document.getElementById('weight');
    if (weightSlider) {
      let val = parseInt(e.target.value);
      if (!isNaN(val) && val >= 45 && val <= 150) {
        weightSlider.value = val;
      }
    }
  }

  // Инициализация загрузки файла для страницы 11
  document.addEventListener('DOMContentLoaded', function() {
    const photoInput = document.getElementById('photo');
    const fileLabel = document.getElementById('file-label-text');
    
    if (photoInput) {
      photoInput.addEventListener('change', function(e) {
        const fileName = e.target.files[0]?.name;
        if (fileName) {
          fileLabel.textContent = fileName;
          
          // Можно добавить предпросмотр изображения если нужно
          // const previewContainer = document.createElement('div');
          // previewContainer.className = 'image-preview';
          // const preview = document.createElement('img');
          // preview.src = URL.createObjectURL(e.target.files[0]);
          // previewContainer.appendChild(preview);
          // this.parentNode.appendChild(previewContainer);
        } else {
          fileLabel.textContent = 'Выберите фото';
        }
      });
    }
  });
});