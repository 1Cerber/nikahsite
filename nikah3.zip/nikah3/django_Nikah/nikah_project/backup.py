import os
import datetime
import sqlite3
import requests
from django.conf import settings

def backup_database():
    backup_dir = os.path.join(settings.BASE_DIR, 'backups')
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    now = datetime.datetime.now()
    timestamp = now.strftime('%Y%m%d_%H%M%S')
    
    db_path = os.path.join(settings.BASE_DIR, 'db.sqlite3')
    backup_path = os.path.join(backup_dir, f'backup_{timestamp}.sqlite3')
    
    with sqlite3.connect(db_path) as source:
        with sqlite3.connect(backup_path) as destination:
            source.backup(destination)
    
    return backup_path

def send_to_telegram(file_path):
    BOT_TOKEN = '6889051274:AAGPxNPGPGPGPGPGPGPGPGPGPGPGPGPGPG'
    CHAT_ID = '-1002084006789'
    
    url = f'https://api.telegram.org/bot{BOT_TOKEN}/sendDocument'
    
    with open(file_path, 'rb') as file:
        files = {'document': file}
        data = {'chat_id': CHAT_ID}
        response = requests.post(url, files=files, data=data)
        
    return response.status_code == 200

def main():
    try:
        backup_path = backup_database()
        
        if send_to_telegram(backup_path):
            print(f"Бэкап успешно создан и отправлен: {backup_path}")
        else:
            print("Ошибка при отправке бэкапа в Telegram")
            
        backup_dir = os.path.join(settings.BASE_DIR, 'backups')
        files = sorted(os.listdir(backup_dir), key=lambda x: os.path.getctime(os.path.join(backup_dir, x)))
        if len(files) > 24:
            for file in files[:-24]:
                os.remove(os.path.join(backup_dir, file))
                
    except Exception as e:
        print(f"Произошла ошибка: {str(e)}")

if __name__ == '__main__':
    main() 