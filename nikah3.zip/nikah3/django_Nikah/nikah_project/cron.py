import os
import sys
from django.core.management import execute_from_command_line

def run_backup():
    # Добавляем путь к проекту в PYTHONPATH
    project_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(project_path)
    
    # Устанавливаем переменную окружения DJANGO_SETTINGS_MODULE
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nikah_project.settings')
    
    # Импортируем и запускаем скрипт бэкапа
    from backup import main
    main()

if __name__ == '__main__':
    run_backup() 